package com.jaborzoda.evolvewarriors;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512); setContentView(new BattleView(this)); }

    static class Unit {
        float x,y,hp,maxHp,speed,attackTimer;
        boolean blue,boss;
        int level;
        Unit(float x,float y,boolean blue,int level,boolean boss) {
            this.x=x; this.y=y; this.blue=blue; this.level=level; this.boss=boss;
            maxHp=hp=(boss?130:36)+level*9; speed=(boss?15:25)+level*2;
        }
    }

    class BattleView extends View {
        Paint p=new Paint(3); Random rng=new Random();
        ArrayList<Unit> allies=new ArrayList<>(), enemies=new ArrayList<>();
        ArrayList<float[]> particles=new ArrayList<>();
        SharedPreferences prefs;
        int wave,coins,kills,upgrade=0; float time=0,spawn=0,ability=0,clone=0;
        boolean paused=false,gameOver=false,showShop=false;
        String message="DEPLOY YOUR WARRIORS";
        long last=System.nanoTime();
        float W=1000,H=600,scale=1,ox=0,oy=0;
        BattleView(Context c) {
            super(c); prefs=getSharedPreferences("save",0);
            wave=prefs.getInt("wave",1); coins=prefs.getInt("coins",0); kills=prefs.getInt("kills",0); upgrade=prefs.getInt("upgrade",0);
            for(int i=0;i<5+upgrade;i++) allies.add(new Unit(110+rng.nextInt(80),230+rng.nextInt(150),true,upgrade,false));
            spawnWave();
        }
        void spawnWave(){ int n=4+wave*2; for(int i=0;i<n;i++) enemies.add(new Unit(820+rng.nextInt(100),210+rng.nextInt(190),false,wave/3,i==n-1&&wave%3==0)); message="WAVE "+wave+" — SURVIVE"; }
        void save(){prefs.edit().putInt("wave",wave).putInt("coins",coins).putInt("kills",kills).putInt("upgrade",upgrade).apply();}
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); W=getWidth(); H=getHeight(); c.save();
            drawBackground(c);
            float dt=Math.min(.05f,(System.nanoTime()-last)/1e9f); last=System.nanoTime();
            if(!paused&&!gameOver&&!showShop) update(dt);
            for(Unit u:allies) drawUnit(c,u); for(Unit u:enemies) drawUnit(c,u);
            drawParticles(c);
            drawHud(c);
            c.restore(); postInvalidateDelayed(16);
        }
        void drawBackground(Canvas c){
            c.drawColor(Color.rgb(22,31,43));
            p.setShader(new LinearGradient(0,0,0,H,Color.rgb(31,52,69),Color.rgb(95,76,58),Shader.TileMode.CLAMP)); c.drawRect(0,0,W,H,p); p.setShader(null);
            p.setColor(Color.rgb(53,61,55)); c.drawRect(0,H*.63f,W,H,p);
            p.setColor(Color.rgb(76,77,63)); for(int i=0;i<10;i++){float x=i*W/9f; c.drawRect(x,H*.62f,x+W*.03f,H,p);}
            p.setColor(Color.argb(80,10,10,10)); for(int i=0;i<16;i++){float x=(i*97f+time*30)%W; c.drawCircle(x,H*.2f+(i%3)*20,4+i%6,p);}
            // hand-drawn battlefield trenches
            p.setColor(Color.rgb(36,42,39)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(8); c.drawLine(0,H*.78f,W,H*.73f,p); p.setStyle(Paint.Style.FILL);
        }
        void update(float dt){
            time+=dt; spawn+=dt;
            if(spawn>2.8f && enemies.size()<4+wave*2){spawn=0; enemies.add(new Unit(850+rng.nextInt(100),220+rng.nextInt(180),false,wave/3,false));}
            moveTeam(allies,enemies,dt); moveTeam(enemies,allies,dt);
            for(int i=enemies.size()-1;i>=0;i--) if(enemies.get(i).hp<=0){Unit u=enemies.remove(i); coins+=3+wave; kills++; burst(u.x,u.y); if(kills%5==0) message="EVOLUTION READY!"; save();}
            for(int i=allies.size()-1;i>=0;i--) if(allies.get(i).hp<=0){Unit u=allies.remove(i);burst(u.x,u.y);}
            if(enemies.isEmpty()){wave++; coins+=10; spawnWave(); save();}
            if(allies.isEmpty()){gameOver=true; message="SQUAD ELIMINATED";}
            if(ability>0) ability-=dt; if(clone>0) clone-=dt;
        }
        void moveTeam(ArrayList<Unit> team,ArrayList<Unit> foes,float dt){
            for(Unit u:team){
                Unit target=null; float best=99999;
                for(Unit f:foes){float d=Math.abs(f.x-u.x)+Math.abs(f.y-u.y)*.6f;if(d<best){best=d;target=f;}}
                if(target==null)continue;
                float dx=target.x-u.x,dy=target.y-u.y,dist=(float)Math.sqrt(dx*dx+dy*dy);
                float reach=u.boss?55:34;
                if(dist>reach){u.x+=dx/(dist+0.01f)*u.speed*dt;u.y+=dy/(dist+0.01f)*u.speed*dt;}
                else {u.attackTimer-=dt;if(u.attackTimer<=0){u.attackTimer=.55f;target.hp-= (5+u.level*2)*(u.blue?1:0.85f); burst(target.x,target.y);}}
                u.x=Math.max(30,Math.min(W-30,u.x));u.y=Math.max(H*.42f,Math.min(H*.78f,u.y));
            }
        }
        void drawUnit(Canvas c,Unit u){
            float s=u.boss?1.6f:1+u.level*.08f;
            float x=u.x,y=u.y;
            p.setColor(Color.argb(90,0,0,0)); c.drawOval(x-15*s,y+18*s,x+15*s,y+25*s,p);
            int color=u.blue?Color.rgb(79,191,255):Color.rgb(234,83,72);
            p.setColor(color); c.drawCircle(x,y-23*s,9*s,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeWidth(4*s);
            c.drawLine(x,y-13*s,x,y+8*s,p); c.drawLine(x,y-6*s,x-9*s,y+1*s,p); c.drawLine(x,y-6*s,x+10*s,y-1*s,p);
            c.drawLine(x,y+8*s,x-8*s,y+19*s,p); c.drawLine(x,y+8*s,x+8*s,y+19*s,p); p.setStyle(Paint.Style.FILL);
            p.setColor(Color.DKGRAY); c.drawRect(x-14*s,y-40*s,x+14*s,y-36*s,p);
            p.setColor(Color.rgb(80,220,105)); c.drawRect(x-14*s,y-40*s,x-14*s+28*s*Math.max(0,u.hp/u.maxHp),y-36*s,p);
            if(u.boss){p.setColor(Color.WHITE);p.setTextSize(12);c.drawText("ELITE",x-16,y-47,p);}
        }
        void burst(float x,float y){for(int i=0;i<5;i++)particles.add(new float[]{x,y,rng.nextFloat()*2-1,rng.nextFloat()*2-1,0.3f});}
        void drawParticles(Canvas c){
            for(int i=particles.size()-1;i>=0;i--){float[] a=particles.get(i);a[0]+=a[2]*3;a[1]+=a[3]*3;a[4]-=.02f;p.setColor(Color.argb((int)(255*Math.max(0,a[4]/.3f)),255,190,70));c.drawCircle(a[0],a[1],3,p);if(a[4]<=0)particles.remove(i);}
        }
        void text(Canvas c,String s,float x,float y,float size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));c.drawText(s,x,y,p);}
        void button(Canvas c,String s,float x,float y,float w,float h){p.setColor(Color.argb(220,18,25,34));c.drawRoundRect(x,y,x+w,y+h,12,12,p);p.setColor(Color.rgb(255,178,54));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawRoundRect(x,y,x+w,y+h,12,12,p);p.setStyle(Paint.Style.FILL);text(c,s,x+12,y+h*.65f,18,Color.WHITE);}
        void drawHud(Canvas c){
            text(c,"EVOLVE  /  OR  DIE",22,32,26,Color.WHITE); text(c,"WAVE "+wave,22,62,19,Color.rgb(255,198,83));
            text(c,"✦ "+coins+"    EVOLUTION "+upgrade,22,89,16,Color.WHITE); text(c,"SQUAD "+allies.size()+"    KILLS "+kills,22,113,16,Color.WHITE);
            button(c,"EVOLVE  "+(50+upgrade*35)+" ✦",W-185,18,165,42);
            button(c,"CLONE",W-185,68,165,42);
            button(c,ability>0?"BLAST "+String.format(Locale.US,"%.1f",ability):"SUPER BLAST",W-185,118,165,42);
            if(paused||showShop||gameOver){
                p.setColor(Color.argb(190,5,9,15));c.drawRect(0,0,W,H,p);
                text(c,gameOver?"DEFEAT":showShop?"EVOLUTION LAB":"PAUSED",W*.36f,H*.35f,36,Color.WHITE);
                if(gameOver){button(c,"RETRY",W*.4f,H*.52f,160,52);button(c,"RESET SAVE",W*.4f,H*.62f,160,48);}
                else if(showShop){button(c,"UPGRADE SQUAD — "+(50+upgrade*35)+" COINS",W*.30f,H*.48f,W*.42f,52);button(c,"BACK TO BATTLE",W*.4f,H*.62f,180,48);}
                else button(c,"RESUME",W*.4f,H*.52f,180,52);
            }
            if(!message.isEmpty()&&!paused&&!showShop&&!gameOver){p.setColor(Color.argb(180,10,14,20));c.drawRoundRect(W*.31f,15,W*.66f,47,8,8,p);text(c,message,W*.33f,36,15,Color.WHITE);}
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            float x=e.getX(),y=e.getY();
            if(gameOver){if(y>H*.50f&&y<H*.62f){gameOver=false;allies.clear();enemies.clear();for(int i=0;i<5+upgrade;i++)allies.add(new Unit(100+rng.nextInt(80),230+rng.nextInt(150),true,upgrade,false));spawnWave();}else if(y>=H*.62f){wave=1;coins=0;kills=0;upgrade=0;save();gameOver=false;allies.clear();enemies.clear();for(int i=0;i<5;i++)allies.add(new Unit(100+rng.nextInt(80),230+rng.nextInt(150),true,0,false));spawnWave();}invalidate();return true;}
            if(showShop){if(y>H*.45f&&y<H*.60f&&coins>=50+upgrade*35){coins-=50+upgrade*35;upgrade++;for(Unit u:allies){u.level++;u.maxHp+=10;u.hp+=10;}message="SQUAD EVOLVED!";save();}else showShop=false;invalidate();return true;}
            if(paused){paused=false;invalidate();return true;}
            if(x>W-200&&y<62){showShop=true;invalidate();return true;}
            if(x>W-200&&y<115){if(coins>=20&&clone<=0){coins-=20;clone=4;for(int i=0;i<2;i++)allies.add(new Unit(100+rng.nextInt(60),250+rng.nextInt(120),true,upgrade,false));message="CLONING COMPLETE";save();}else message="NEED 20 COINS / WAIT";invalidate();return true;}
            if(x>W-200&&y<170){if(ability<=0){ability=8;for(Unit u:enemies)u.hp-=18+upgrade*3;message="SUPER BLAST!";}invalidate();return true;}
            if(x<70&&y<45){paused=true;invalidate();return true;}
            // Tap battlefield to rally squad toward the chosen position.
            for(Unit u:allies){u.x+=Math.signum(x-u.x)*25;u.y+=Math.signum(y-u.y)*12;}
            invalidate();return true;
        }
    }
}
